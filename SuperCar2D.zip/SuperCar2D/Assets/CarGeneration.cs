﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;

public class CarGeneration : MonoBehaviour
{
    public GameObject carPopulation;
    public GameObject integerToStr;
    [SerializeField] GameObject carPrefab;
    public GameObject mainCamera;
    public GameObject terrainCreator;

    [HideInInspector]
    public float bestDistance = 0f;
    [HideInInspector]
    public List<float> historyOfBestDistances;
    [HideInInspector]
    public int indexBest = 0;

    public int populationSize = 2;
    Vector3 initPosition = new Vector3(0f, 0f, 1f);
    private int amountOfDeadCars = 0;

    private bool generatingPopulation = false;

    private float[] carDistances;

    public float mutationProbability = 0.15f;
    public float crossingProbability = 0.15f;

    private void Start()
    {
        historyOfBestDistances = new List<float>();
        carDistances = new float[populationSize];
        amountOfDeadCars = 0;
        generatingPopulation = false;
        initPosition = new Vector3(0f, 0f, 1f);
        indexBest = 0;
        StartCoroutine(generatePopAfterSeconds(generateFirstPopulation, 0.01f));
    }

    IEnumerator generatePopAfterSeconds(Func<int> genPop, float seconds)
    {
        generatingPopulation = true;

        yield return new WaitForSeconds(seconds);

        genPop();

        generatingPopulation = false;
    }

    private void Update()
    {
        if(!generatingPopulation)
        {
            for (int i = 0; i < carPopulation.transform.childCount; i++)
            {
                // Szukam najlepszej wartości dystansu i osobnika, który go przebył
                float carDistance = carPopulation.transform.GetChild(i).GetComponent<CarController>().bestDistance;

                if (bestDistance <= carDistance)
                {
                    bestDistance = carDistance;
                    indexBest = i;
                }

                if (carPopulation.transform.GetChild(i).GetComponent<CarController>().isDead == true)
                {
                    amountOfDeadCars++;
                }
            }

            if(amountOfDeadCars >= populationSize)
            {
                historyOfBestDistances.Add(bestDistance);

                amountOfDeadCars = 0;
                terrainCreator.GetComponent<TerrainCreator>().generateNewTerrain();
                StartCoroutine(generatePopAfterSeconds(generateNewPopulation, 0.01f));
            }
            amountOfDeadCars = 0;
        }
    }

    private int generateFirstPopulation()
    {
        for (int i = 0; i < populationSize; i++)
        {
            GameObject newCar = Instantiate(carPrefab, initPosition, Quaternion.identity);
            newCar.transform.parent = carPopulation.transform;
        }

        //mainCamera.GetComponent<Follow>().target = carPopulation.transform.GetChild(0).transform;

        // selekcja
        //int[] TtIndeces = selection();
        // operatory genetyczne
        //geneticOperators(TtIndeces);

        mainCamera.GetComponent<Follow>().initialize();

        return 0;
    }

    public int generateNewPopulation()
    {
        bestDistance = 0f;
        indexBest = 0;

        // sukcesja usuwa wszystkich osobników, po czym tworzy populację nowych i lepszych
        succession();

        // selekcja
        int[] TtIndeces = selection();
        //foreach (int index in TtIndeces)
          //  Debug.Log(index);
        // operatory genetyczne
        geneticOperators(TtIndeces);


        integerToStr.GetComponent<IntegerToString>().triggerNewGeneration();
        mainCamera.GetComponent<Follow>().initialize();

        return 0;
    }

    private int[] selection()
    {
        // Selekcja proporcjonalna
        
        float[] p = new float[populationSize];
        float sumOfFitness = sumOfFit();

        for (int i = 0; i < populationSize; i++)
        {
            p[i] = carDistances[i] / sumOfFitness;
            carDistances[i] = 0f;
        }

        // Tutaj na podstawie wag losujemy Floor(populationSize / 2) osobników
        int[] TtInd = getRandomWeightedIndeces(p);
        
        return TtInd;
    }
    
    private void geneticOperators(int[] TtInd)
    {
        // Krzyżowanie
        for (int i = 0; i < TtInd.Length - 1; i++)
        {
            if(UnityEngine.Random.Range(0f, 1f) <= crossingProbability)
            {
                carPopulation.transform.GetChild(TtInd[i]).GetComponent<CarController>().crossWith(carPopulation.transform.GetChild(TtInd[i + 1]));
            }

        }

        // Mutowanie
        for (int i = 0; i < TtInd.Length; i++)
        {
            if (UnityEngine.Random.Range(0f, 1f) <= mutationProbability)
            {
                carPopulation.transform.GetChild(TtInd[i]).GetComponent<CarController>().mutate(0.6f);
            }
        }
    }

    private void succession()
    {
        int[] OtInd = new int[populationSize];

        for (int i = 0; i < populationSize; i++)
        {
            OtInd[i] = i;
        }

        // sukcesja będzie usuwała osobników z początku tabeli OtInd,
        // bo mają oni najgorsze przystosowanie

        GFG gg = new GFG();
        // combined jest sortowane na podstawie wartości przystosowania osobników
        Array.Sort(OtInd, gg);

        GameObject[] newPopulation = new GameObject[populationSize];

        Debug.Log("Najlepszy z dystansem: "+carPopulation.transform.GetChild(OtInd[0]).gameObject.GetComponent<CarController>().bestDistance);
        Debug.Log("Najgorszy z dystansem: "+carPopulation.transform.GetChild(OtInd[OtInd.Length - 1]).gameObject.GetComponent<CarController>().bestDistance);

        for (int i = 0; i < populationSize; i++)
        {
            carDistances[i] = carPopulation.transform.GetChild(OtInd[i]).gameObject.GetComponent<CarController>().bestDistance;
            newPopulation[i] = Instantiate(carPopulation.transform.GetChild(OtInd[i]).gameObject, initPosition, Quaternion.identity);
            newPopulation[i].name = "Car " + i.ToString();
            newPopulation[i].SetActive(false);
        }

        //GameObject[] unwantedCars = GameObject.FindGameObjectsWithTag("Car");

        // Usuwanie wszystkich osobników
        foreach(Transform child in carPopulation.transform)
        {
            Destroy(child.gameObject);
        }

        carPopulation.transform.DetachChildren();

        // Utworzenie nowej populacji na podstawie zapisanych prefabów
        for (int i = 0; i < populationSize; i++)
        {
            newPopulation[i].SetActive(true);
            newPopulation[i].transform.parent = carPopulation.transform;
        }
    }

    private float sumOfFit()
    {
        float sum = 0f;

        for (int i = 0; i < populationSize; i++)
        {
            sum += carPopulation.transform.GetChild(i).GetComponent<CarController>().bestDistance;
        }

        return sum;
    }

    private int[] getRandomWeightedIndeces(float[] weights)
    {
        int numOfIndeces = Mathf.FloorToInt(weights.Length / 2);
        int[] indeces = new int[numOfIndeces];

        float totalWeight = 0f;

        foreach (float weight in weights)
        {
            totalWeight += weight;
        }

        for (int k = 0; k < numOfIndeces; k++)
        {
            int index = UnityEngine.Random.Range(0, weights.Length);

            float randWeightValue = UnityEngine.Random.Range(0, totalWeight);
            float processedWeight = 0;

            for (int i = 0; i < weights.Length; i++)
            {
                processedWeight += weights[i];

                if (randWeightValue <= processedWeight)
                {
                    index = i;
                    break;
                }
            }

            indeces[k] = index;
        }

        return indeces;
    }
}
class GFG : IComparer<int>
{
    private GameObject carPopulation = GameObject.FindGameObjectWithTag("Population");
    public int Compare(int index1, int index2)
    {
        float dist1 = carPopulation.transform.GetChild(index1).GetComponent<CarController>().bestDistance;
        float dist2 = carPopulation.transform.GetChild(index2).GetComponent<CarController>().bestDistance;

        return dist1 > dist2 ? -1 : 1;

    }
}