﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class TerrainCreator : MonoBehaviour
{
    private SpriteShapeController shape;
    public int scale = 1000;

    public int numOfPoints = 100;

    bool firstGeneration = true;
    void Start()
    {
        firstGeneration = true;
        shape = GetComponent<SpriteShapeController>();
        generateNewTerrain();
    }
    public void generateNewTerrain()
    {
        if (firstGeneration)
        {
            shape.spline.SetPosition(2, shape.spline.GetPosition(2) + Vector3.right * scale);
            shape.spline.SetPosition(3, shape.spline.GetPosition(3) + Vector3.right * scale);
            //}
            //else
            {
                for (int i = 0; i < numOfPoints; i++)
                {
                    shape.spline.RemovePointAt(2);
                }
            }

            float distanceBtwPoints = scale / numOfPoints;

            shape.spline.InsertPointAt(2, new Vector3(shape.spline.GetPosition(1).x + distanceBtwPoints * 4, 1, 0));

            for (int i = 1; i < numOfPoints; i++)
            {
                float xPos = shape.spline.GetPosition(i + 1).x + distanceBtwPoints;

                shape.spline.InsertPointAt(i + 2, new Vector3(xPos, Random.Range(-1f, 1f) * 6f * Mathf.PerlinNoise(i * Random.Range(1f, 8f), 0)));
            }

            for (int i = 2; i < numOfPoints + 2; i++)
            {
                shape.spline.SetTangentMode(i, ShapeTangentMode.Continuous);
                shape.spline.SetLeftTangent(i, new Vector3(-1.7f, 0, 0));
                shape.spline.SetRightTangent(i, new Vector3(1.7f, 0, 0));
            }

            firstGeneration = false;
        }
    }
}
