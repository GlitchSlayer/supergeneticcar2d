﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Follow : MonoBehaviour
{
    [HideInInspector] public Transform target;
    private Vector3 offset;
    public GameObject carPopulation;
    public GameObject carGenerator;
    public GameObject intToString;

    private Vector3 startPosition;
    private float startSize;

    // Start is called before the first frame update
    void Start()
    {
        startPosition = transform.position;
        startSize = GetComponent<Camera>().orthographicSize;
        initialize();
    }

    // Update is called once per frame
    void Update()
    {
        if(carPopulation.transform.childCount > 0)
        {
            if(!carPopulation.transform.GetChild(carGenerator.GetComponent<CarGeneration>().indexBest).GetComponent<CarController>().isDead)
                target = carPopulation.transform.GetChild(carGenerator.GetComponent<CarGeneration>().indexBest).transform;
            else
            {
                foreach(Transform child in carPopulation.transform)
                {
                    if (!child.GetComponent<CarController>().isDead)
                        target = child.transform;
                }
            }
        }

        transform.position = target.position + offset;
    }
    public void initialize()
    {
        transform.position = startPosition;
        GetComponent<Camera>().orthographicSize = startSize;
        target = GameObject.FindGameObjectWithTag("Population").transform;
        offset = transform.position - target.position;
        StartCoroutine(changeSize());
    }

    IEnumerator changeSize()
    {
        for(int i=0; i < 100; i++)
        {
            yield return new WaitForSeconds(0.01f);
            GetComponent<Camera>().orthographicSize -= 5/100f;
        }
    }
}
