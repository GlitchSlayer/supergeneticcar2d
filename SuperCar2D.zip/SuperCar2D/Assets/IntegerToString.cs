﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IntegerToString : MonoBehaviour
{
    public GameObject carPopulation;
    public GameObject carGenerator;
    public GameObject mainCamera;

    private int generation = 1;
    private int populationSize = 0;
    
    public Text generationText;
    public Text populationText;
    public Text mutChanceText;
    public Text crossChanceText;
    public Text distText;

    private void Start()
    {
        // Time.timeScale = 2;
    }

    void Update()
    {
        generationText.text = generation.ToString();
        populationSize = carPopulation.transform.childCount;
        populationText.text = populationSize.ToString();
        mutChanceText.text = carGenerator.GetComponent<CarGeneration>().mutationProbability.ToString();
        crossChanceText.text = carGenerator.GetComponent<CarGeneration>().crossingProbability.ToString();
        distText.text = carGenerator.GetComponent<CarGeneration>().bestDistance.ToString();
    }

    public void triggerNewGeneration()
    {
        generation++;
    }

}