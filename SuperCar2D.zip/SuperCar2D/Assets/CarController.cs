﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.U2D;

public class CarController : MonoBehaviour
{
    public Rigidbody2D carRigidbody;
    public Rigidbody2D backTire;
    public Rigidbody2D frontTire;
    public SpriteShapeController shapeController;
    public float speed = 50f;
    private float movement = 1f;
    public float bestDistance = 0f;
    private float lastDistance;

    [HideInInspector]
    public bool isDead = false;
    private bool isCoroutineOn = false;

    void Start()
    {
        bestDistance = 0f;
        lastDistance = 0f;
        isDead = false;
        isCoroutineOn = false;
    }

    private void FixedUpdate()
    {
        if (!isDead)
        {
            if(backTire.GetComponent<OnGroundBehaviour>().onGround)
                backTire.AddTorque(-movement * speed * Time.fixedDeltaTime);
            if (backTire.GetComponent<OnGroundBehaviour>().onGround)
                frontTire.AddTorque(-movement * speed * Time.fixedDeltaTime);

            carRigidbody.AddTorque(-movement * (speed / 10f) * Time.fixedDeltaTime);
            
            checkIfDead();
        }
        
        if (transform.position.x >= bestDistance)
        {
            bestDistance = transform.position.x;
        }
    }

    private void checkIfDead()
    {
        if(transform.position.x < bestDistance + 0.55f)
        {
            if(!isCoroutineOn)
            {
                StartCoroutine(waitForDeath());
            }
        }
    }

    IEnumerator waitForDeath()
    {
        isCoroutineOn = true;

        lastDistance = bestDistance;

        yield return new WaitForSeconds(3.5f);

        if (transform.position.x < lastDistance + 0.55f)
        {
            isDead = true;
        }
        isCoroutineOn = false;
    }

    public void crossWith(Transform otherCar)
    {
        float ksi = Random.Range(0f, 1f);

        // krzyżowanie uśredniające
        speed += ksi * (otherCar.gameObject.GetComponent<CarController>().speed - speed);

        for (int i = 0; i < shapeController.spline.GetPointCount(); i++)
        {
            shapeController.spline.SetPosition(i, shapeController.spline.GetPosition(i) + ksi * (otherCar.gameObject.GetComponent<CarController>().shapeController.spline.GetPosition(i) - shapeController.spline.GetPosition(i)));
        }

        attachWheels();

        backTire.gameObject.transform.localScale += ksi * (otherCar.gameObject.GetComponent<CarController>().backTire.gameObject.transform.localScale - backTire.gameObject.transform.localScale);
        frontTire.gameObject.transform.localScale += ksi * (otherCar.gameObject.GetComponent<CarController>().frontTire.gameObject.transform.localScale - frontTire.gameObject.transform.localScale);

    }
    public void mutate(float mutationCoefficient)
    {
        // mutationCoefficient określa jak duża ma być mutacja; ma wartości od 0 do 1
        // losuje się prędkość pojazdku
        speed += mutationCoefficient * Random.Range(-30, 30);


        // losuje się kształt pojazdu
        for(int i = 0; i < shapeController.spline.GetPointCount(); i++)
        {
            shapeController.spline.SetPosition(i, shapeController.spline.GetPosition(i) + mutationCoefficient * new Vector3(Random.Range(-1.75f, 1.75f), Random.Range(-1.75f, 1.75f), 0f));
        }

        // doczepiam koła do tego kształtu
        attachWheels();
        
        // losowo zmieniam wielkość kół
        backTire.gameObject.transform.localScale += mutationCoefficient * Random.Range(-0.3f, 0.7f) * new Vector3(1f, 1f);
        frontTire.gameObject.transform.localScale += mutationCoefficient * Random.Range(-0.3f, 0.7f) * new Vector3(1f, 1f);
    }

    private void attachWheels()
    {
        backTire.gameObject.transform.localPosition = new Vector3(shapeController.spline.GetPosition(0).x, shapeController.spline.GetPosition(0).y - 0.3f, 2);
        frontTire.gameObject.transform.localPosition = new Vector3(shapeController.spline.GetPosition(3).x, shapeController.spline.GetPosition(3).y - 0.3f, 2);

        backTire.gameObject.GetComponent<WheelJoint2D>().connectedAnchor = new Vector2(backTire.gameObject.transform.localPosition.x, backTire.gameObject.transform.localPosition.y + 0.2f);
        frontTire.gameObject.GetComponent<WheelJoint2D>().connectedAnchor = new Vector2(frontTire.gameObject.transform.localPosition.x, frontTire.gameObject.transform.localPosition.y + 0.2f);
    }
}